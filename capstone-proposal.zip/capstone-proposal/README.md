Datasets:

Dog images were acquired from Udacity's dataset archives on AWS:
https://s3-us-west-1.amazonaws.com/udacity-aind/dog-project/dogImages.zip

Human images were acquired from Udacity's dataset archives AWS:
https://s3-us-west-1.amazonaws.com/udacity-aind/dog-project/lfw.zip
